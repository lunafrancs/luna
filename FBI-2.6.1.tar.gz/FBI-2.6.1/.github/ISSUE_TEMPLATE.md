Before creating an issue, remember that FBI does not work on systems without custom firmware on 11.3. There is no kernel exploit for this version yet, and there are currently no estimates when another one will be found.

If you are experiencing issues installing a CIA file, please make sure that:
* Your CIA file is valid.
* Your SD card is good.
  * Make sure you don't have a counterfeit SD card.
  * Check the SD card for filesystem errors.
  * Try a different SD card, if possible.
