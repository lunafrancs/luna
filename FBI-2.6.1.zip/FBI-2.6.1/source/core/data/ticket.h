#pragma once

Result ticket_get_title_id(u64* titleId, u8* ticket, size_t size);