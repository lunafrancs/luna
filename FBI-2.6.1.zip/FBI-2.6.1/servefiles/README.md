# servefiles

Simple Python script for serving local files to FBI's remote installer. Requires [Python](https://www.python.org/downloads/).

**Usage**: python servefiles.py (3ds ip) (file / directory) \[host ip\] \[host port\]

  - Supported file extensions: .cia, .tik, .cetk, .3dsx
